// #ifndef CATA_HPP
// #define CATA_HPP

#include "vex.h"
void handleCataBehavior();
void handleMovementBehavior();
void intake();
// class Catapult
// {
// public:
//   static void handleCataBehavior();
// };
//#endif
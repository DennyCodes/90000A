#include "vex.h"
#include "robot-config.h"



class PIDController {
public:
    PIDController(double Kp, double Ki, double Kd);

    double calculateOutput(double target_value, double sensor_reading);

private:
    double Kp_;
    double Ki_;
    double Kd_;
    double error_;
    double integral_;
    double derivative_;
    double previous_error_;
    time_t previous_time_;
};
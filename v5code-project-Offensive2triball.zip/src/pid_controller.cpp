
#include "vex.h"
#include "pid_controller.h"
#include "robot-config.h"

#include <time.h>

//constructor
PIDController::PIDController(double Kp, double Ki, double Kd) :
    Kp_(Kp),
    Ki_(Ki),
    Kd_(Kd),
    error_(0),
    integral_(0),
    derivative_(0),
    previous_error_(0),
    previous_time_(time(NULL)) {}

double PIDController::calculateOutput(double target_value, double sensor_reading) {
    //error
    error_ = target_value - sensor_reading;
    //integral without delta time
    integral_ += error_;

    // Limit integral term
    if (integral_ > 100) {
        integral_ = 100;
    } else if (integral_ < -100) {
        integral_ = -100;
    }

    derivative_ = (error_ - previous_error_) / (time(NULL) - previous_time_); //deltaTime or some
    previous_error_ = error_; // making new prev for next run
    previous_time_ = time(NULL); // same thing here

    double speed = Kp_ * error_ + Ki_ * integral_ + Kd_ * derivative_; //calc for speed formula

    // Limit speed, problem: doesnt work on vex voltage but its fine
    if (speed > 100) {
        speed = 100;
    } else if (speed < -100) {
        speed = -100;
    }

    return speed;
}
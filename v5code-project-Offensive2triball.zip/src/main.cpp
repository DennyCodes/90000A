 /*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\gencd                                            */
/*    Created:      Sat Sep 16 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// a                    motor         1               
// b                    motor         2               
// c                    motor         3               
// d                    motor         4               
// e                    motor         5               
// f                    motor         6               
// CataRot              rotation      13              
// CataMotor            motor         18              
// IntakeMotor          motor         7               
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "cata.h"
//#include "extension.h"
#include "vex.h"
//#include "robot-config.h"
#include <chrono>
#include <cmath>
#include "pid_controller.h"

using namespace vex;

competition Competition;

// Initializing Robot Configuration. DO NOT REMOVE!


void pre_auton(void) {
  vexcodeInit();
}



void autonomous() {
  PIDController turnPID(0.5, 0.2, 0.1);
  RightMotorGroup.setVelocity(7, percent);
  hang.setVelocity(100, percent);
  hang.setMaxTorque(100, percent);
  IntakeMotor.setMaxTorque(100, percent);
  LeftMotorGroup.setVelocity(7, percent);
  IntakeMotor.setVelocity(100, percent);
  
  double leftMotorEncoderPosition = LeftMotorGroup.position(vex::rotationUnits::rev)  ;
  double rightMotorEncoderPosition = RightMotorGroup.position(vex::rotationUnits::rev);

      // Calculate the current heading of the robot
  double currentHeading = (leftMotorEncoderPosition - rightMotorEncoderPosition); // (LeftMotorGroup.getCountsPerRevolution() + rightMotorEncoder.getCountsPerRevolution())*360;



      // Set the target heading
  double targetHeading = 90; 
  double motor_power = turnPID.calculateOutput(targetHeading, currentHeading);

//   autonomous();
  // auto start = std::chrono::high_resolution_clock::now();
  // double elapsed=0;
  // IntakeMotor.spin(forward,12,voltageUnits::volt);
  // vex::task::sleep(8580);
  LeftMotorGroup.spin(forward,6,voltageUnits::volt);
  RightMotorGroup.spin(forward,6,voltageUnits::volt);
  vex::task::sleep(1069);
  leftMotorEncoderPosition = LeftMotorGroup.position(vex::rotationUnits::rev)  ;
  rightMotorEncoderPosition = RightMotorGroup.position(vex::rotationUnits::rev);

      // Calculate the current heading of the robot
  currentHeading = (leftMotorEncoderPosition - rightMotorEncoderPosition); // (LeftMotorGroup.getCountsPerRevolution() + rightMotorEncoder.getCountsPerRevolution())*360;



      // Set the target heading
  targetHeading = 90; 
  motor_power = turnPID.calculateOutput(targetHeading, currentHeading);
  
  for (int i =0; i<55; i++) {
    LeftMotorGroup.spin(forward, motor_power/100*12, voltageUnits::volt);
    RightMotorGroup.spin(forward, -motor_power/100*12, voltageUnits::volt);
    IntakeMotor.spin(forward,3,voltageUnits::volt);
    vex::task::sleep(5);
  }
    
    // hang.spin(vex::reverse, 12, vex::voltageUnits::volt);
    // vex::task::sleep(25);
  

  RightMotorGroup.setVelocity(10, percent);
  LeftMotorGroup.setVelocity(10, percent);
  IntakeMotor.spin(forward,6,voltageUnits::volt);
  LeftMotorGroup.spin(forward,6,voltageUnits::volt);
  RightMotorGroup.spin(forward,6,voltageUnits::volt);
  vex::task::sleep(300);
  //IntakeMotor.spin(forward,12,voltageUnits::volt);
  LeftMotorGroup.spin(reverse,6,voltageUnits::volt);
  RightMotorGroup.spin(reverse,6,voltageUnits::volt);
  vex::task::sleep(369);
  LeftMotorGroup.spin(forward,9,voltageUnits::volt);
  RightMotorGroup.spin(forward,9,voltageUnits::volt);
  vex::task::sleep(469);
  LeftMotorGroup.spin(reverse,6,voltageUnits::volt);
  RightMotorGroup.spin(reverse,6,voltageUnits::volt);
  vex::task::sleep(80);
  IntakeMotor.spin(forward,5,voltageUnits::volt);
  LeftMotorGroup.spin(forward,9,voltageUnits::volt);
  RightMotorGroup.spin(forward,9,voltageUnits::volt);
  vex::task::sleep(100);
  LeftMotorGroup.spin(reverse,6,voltageUnits::volt);
  RightMotorGroup.spin(reverse,6,voltageUnits::volt);
  vex::task::sleep(590);
  leftMotorEncoderPosition = LeftMotorGroup.position(vex::rotationUnits::rev)  ;
  rightMotorEncoderPosition = RightMotorGroup.position(vex::rotationUnits::rev);

      // Calculate the current heading of the robot
  currentHeading = (leftMotorEncoderPosition - rightMotorEncoderPosition); // (LeftMotorGroup.getCountsPerRevolution() + rightMotorEncoder.getCountsPerRevolution())*360;



      // Set the target heading
  targetHeading = 90; 
  motor_power = turnPID.calculateOutput(targetHeading, currentHeading);
  
  for (int i =0; i<40; i++) {
    LeftMotorGroup.spin(forward, -motor_power/100*12, voltageUnits::volt);
    RightMotorGroup.spin(forward, motor_power/100*12, voltageUnits::volt);
    vex::task::sleep(5);
  }
  IntakeMotor.spin(reverse,12,voltageUnits::volt);
  vex::task::sleep(69);
  IntakeMotor.spin(reverse,12,voltageUnits::volt);
  LeftMotorGroup.spin(forward,5,voltageUnits::volt);
  RightMotorGroup.spin(forward,5,voltageUnits::volt);
  vex::task::sleep(269);
  IntakeMotor.spin(reverse,12,voltageUnits::volt);
  vex::task::sleep(220);
  leftMotorEncoderPosition = LeftMotorGroup.position(vex::rotationUnits::rev)  ;
  rightMotorEncoderPosition = RightMotorGroup.position(vex::rotationUnits::rev);

      // Calculate the current heading of the robot
  currentHeading = (leftMotorEncoderPosition - rightMotorEncoderPosition); // (LeftMotorGroup.getCountsPerRevolution() + rightMotorEncoder.getCountsPerRevolution())*360;



      // Set the target heading
  targetHeading = 90; 
  motor_power = turnPID.calculateOutput(targetHeading, currentHeading);
  
  for (int i =0; i<55; i++) {
    LeftMotorGroup.spin(forward, motor_power/100*12, voltageUnits::volt);
    RightMotorGroup.spin(forward, -motor_power/100*12, voltageUnits::volt);
    vex::task::sleep(5);
  }
  IntakeMotor.spin(forward,6,voltageUnits::volt);
  LeftMotorGroup.spin(forward,10,voltageUnits::volt);
  RightMotorGroup.spin(forward,10,voltageUnits::volt);
  vex::task::sleep(420);
  LeftMotorGroup.spin(reverse,8,voltageUnits::volt);
  RightMotorGroup.spin(reverse,8,voltageUnits::volt);
  vex::task::sleep(120);
  LeftMotorGroup.spin(forward,10,voltageUnits::volt);
  RightMotorGroup.spin(forward,10,voltageUnits::volt);
  vex::task::sleep(269);
  vex::task::sleep(5);
  LeftMotorGroup.spin(reverse,6,voltageUnits::volt);
  RightMotorGroup.spin(forward,6,voltageUnits::volt);
  vex::task::sleep(250);
  vex::task::sleep(25);
  vex::task::sleep(5);
  LeftMotorGroup.spin(reverse,12,voltageUnits::volt);
  RightMotorGroup.spin(forward,12,voltageUnits::volt);
  vex::task::sleep(350);
  vex::task::sleep(5);
  
  



  IntakeMotor.spin(forward,0,voltageUnits::volt);
  LeftMotorGroup.spin(forward,0,voltageUnits::volt);
  RightMotorGroup.spin(forward,0,voltageUnits::volt);
  vex::task::sleep(10000);
} 
  //driveForward(10);
  //turnToHeading(45);
  // LeftMotorGroup.spin(vex::forward,  Controller1.Axis3.position() +  Controller1.Axis1.position() / 100.0f * 12.0f, vex::voltageUnits::volt);
  
  // RightMotorGroup.spin(vex::forward,  Controller1.Axis3.position() +  Controller1.Axis1.position() / 100.0f * 12.0f, vex::voltageUnits::volt);



void usercontrol(void) {
  // ResetAtBottom(); 
  RightMotorGroup.setVelocity(20, percent);
  hang.setVelocity(100, percent);
  hang.setMaxTorque(100, percent);
  IntakeMotor.setMaxTorque(100, percent);
  LeftMotorGroup.setVelocity(20, percent);
  IntakeMotor.setVelocity(100, percent);
  while (1) {
    // Catapult j;
    
  
    RightMotorGroup.setVelocity(20, percent);
    hang.setVelocity(100, percent);
    hang.setMaxTorque(100, percent);
    IntakeMotor.setMaxTorque(100, percent);
    LeftMotorGroup.setVelocity(20, percent);
    IntakeMotor.setVelocity(100, percent);
    intake();
    //handleCataBehavior();
    if (Controller1.ButtonR2.pressing()) {
      hang.spin(vex::forward, 12, vex::voltageUnits::volt);
    }
    else if (Controller1.ButtonR1.pressing()) {
      hang.spin(vex::reverse, 12, vex::voltageUnits::volt);
    }
    else {
      hang.stop();
    }
    handleMovementBehavior();
    
    //DriverControl();
    //wait is so the cpu doesn't overheat or something
    vex::task::sleep(20);
  }
}


//using namespace vex;
int main() { 
  
  
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  pre_auton(); 
  while (true) {
    vex::task::sleep(100);
  }
  // autonomous(autonomous);
  // drivercontrol(usercontrol)
//idk
}



  


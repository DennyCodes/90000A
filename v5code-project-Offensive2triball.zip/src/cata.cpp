/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Edward                                           */
/*    Created:      Sat Apr 01 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// CataRot              rotation      2               
// CataMotor            motor         1               
// Controller1          controller                    
// IntakeMotor          motor         5               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
using namespace vex;
#include "cata.h"
#include "robot-config.h"
#include <cmath>
//#include "robot-config.cpp"
//#include "robot-config.h"
// -- CONFIGURATION -- 

// -- CATA VARIABLES --
bool cataActive = false;
bool cataTop = false;
// const int cataSpeed = 12;
// const int cataStop = 57;
// const int cataAtTop = 20;
// ---------------------


bool isHoldingIntakeButton = false;
// ------------------------

void intake(){
  if(Controller1.ButtonL2.pressing()){
    IntakeMotor.spin(vex::forward, 12, vex::voltageUnits::volt);
    isHoldingIntakeButton = true;
  }
  else if (Controller1.ButtonL1.pressing()){
    IntakeMotor.spin(vex::reverse, 12, vex::voltageUnits::volt);
    isHoldingIntakeButton = true;
  }
  else{
    IntakeMotor.spin(vex::forward, 0, vex::voltageUnits::volt);
  }

}



void handleCataBehavior() {
  //HAng lmao
  

//   if (Controller1.ButtonL1.pressing()&&isHoldingIntakeButton==false) {
//     cataActive = true;
//   }

//   if (cataActive) {
//     CataMotor.spin(vex::forward, cataSpeed, vex::voltageUnits::volt);

//     if (CataRot.angle() < cataAtTop) {
//       cataTop = true;
//     }

//     if (cataTop && CataRot.angle() > cataStop) {
//       cataActive = false;
//       cataTop = false;
//       //CataRot.resetPosition();
//     }
//   } else {
//     CataMotor.stop();
//   }

//  if (Controller1.ButtonL1.pressing()&&isHoldingIntakeButton==false) {
//     cataActive=true;
//  }
//  if (cataActive) {
//     CataMotor.spin(vex::forward, cataSpeed, vex::voltageUnits::volt);
//     if (CataMotor.position(deg) < cataAtTop) {
//       cataTop = true;
//     }
//     if (cataTop){
//       CataMotor.startSpinTo(10, deg );
//       cataActive=false; 
//       cataTop=false;
//     }
//  }
//  else{
//    CataMotor.stop();
//  }

}

void handleMovementBehavior() {
  // int dead_zone = 3;
  // int leftJoy = Controller1.Axis3.position();
  // int rightJoy = Controller1.Axis1.position();
  // while (1) {
    
  //   if (abs(leftJoy) < dead_zone) {
  //     leftJoy=0;
  //   }
  //   if (abs(rightJoy)<dead_zone) {
  //     rightJoy=0;
  //   }
    
  // }
  // float leftOutput = (Controller1.Axis3.position() +  Controller1.Axis1.position()) / 100;
  // float rightOutput = (Controller1.Axis3.position() - Controller1.Axis1.position()) / 100;

  // const float mag = fmax(std::abs(leftOutput), std::abs(rightOutput));

  // if (mag > 1) {
  //   leftOutput /= mag;
  //   rightOutput /= mag;
  // }

  // LeftMotorGroup.spin(vex::forward, leftOutput * 12, vex::voltageUnits::volt);
  // RightMotorGroup.spin(vex::forward, rightOutput * 12, vex::voltageUnits::volt);
  LeftMotorGroup.spin(vex::forward,  (Controller1.Axis3.position() +  0.8*Controller1.Axis1.position()) / 100.0f * 12.0f, vex::voltageUnits::volt); // in voltage
  RightMotorGroup.spin(vex::forward, (Controller1.Axis3.position() - 0.8*Controller1.Axis1.position()) / 100.0f * 12.0f, vex::voltageUnits::volt); // in voltage
}



#include "extension.h"
#include "vex.h"


// void DriverControl() {
//     if (Controller1.ButtonB.pressing()) {
//         Piston.set(true);
//     }
//     else {
//         Piston.set(false);
//     }
// }